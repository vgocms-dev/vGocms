(function () {
    'use strict';

    var STORAGE_KEY = 'admin_menu_palette_recent_v1';
    var MAX_RECENT = 8;

    function readI18n() {
        var el = document.getElementById('admin-menu-palette-i18n');
        if (!el || !el.textContent) {
            return {
                title: 'Menu search',
                hint: 'Search admin pages…',
                recent: 'Recent',
                allLabel: 'All pages',
                empty: 'No matching pages',
            };
        }
        try {
            return JSON.parse(el.textContent);
        } catch (e) {
            return {};
        }
    }

    var i18n = readI18n();
    var root = document.getElementById('adminMenuPalette');
    var btn = document.getElementById('adminMenuPaletteBtn');
    var backdrop = document.getElementById('adminMenuPaletteBackdrop');
    var input = document.getElementById('adminMenuPaletteInput');
    var listEl = document.getElementById('adminMenuPaletteList');
    var panel = document.getElementById('adminMenuPalettePanel');
    if (!root || !btn || !backdrop || !input || !listEl) return;

    function adminBase() {
        var b = typeof window.__adminBase === 'string' ? window.__adminBase.trim() : '';
        if (!b) return '/admin';
        return b.charAt(0) === '/' ? b : '/' + b;
    }

    function normPathname(p) {
        if (!p) return '';
        p = String(p).split('?')[0];
        if (p.length > 1 && p.lastIndexOf('/') === p.length - 1) return p.slice(0, -1);
        return p;
    }

    function stripEmbedFromPath(pathQueryHash) {
        try {
            var u = new URL(pathQueryHash, window.location.origin);
            u.searchParams.delete('embed');
            return u.pathname + (u.search || '') + u.hash;
        } catch (e) {
            return pathQueryHash;
        }
    }

    function isAdminPath(pathname) {
        var base = adminBase();
        return pathname === base || pathname.indexOf(base + '/') === 0;
    }

    function titleFromAnchor(a) {
        var dt = a.getAttribute('data-ws-tab-title');
        if (dt != null && String(dt).trim() !== '') return String(dt).trim();
        var sp = a.querySelector('span.font-medium, span');
        var t = (sp && sp.textContent && sp.textContent.trim()) || (a.textContent || '').trim();
        return t.replace(/\s+/g, ' ').trim();
    }

    function collectItems() {
        var seen = new Set();
        var out = [];
        document.querySelectorAll('aside a[href], #mobileSidebar a[href]').forEach(function (a) {
            if (a.getAttribute('target') === '_blank') return;
            if (a.getAttribute('download') != null) return;
            var hrefAttr = a.getAttribute('href');
            if (!hrefAttr || hrefAttr.indexOf('#') === 0 || hrefAttr.indexOf('javascript:') === 0) return;
            var u;
            try {
                u = new URL(a.href, window.location.origin);
            } catch (e) {
                return;
            }
            if (u.origin !== window.location.origin) return;
            if (!isAdminPath(u.pathname)) return;
            var pathKey = u.pathname + u.search;
            var title = titleFromAnchor(a);
            if (!title) return;
            var dedupe = pathKey + '\n' + title;
            if (seen.has(dedupe)) return;
            seen.add(dedupe);
            var iconEl = a.querySelector('i[data-lucide]');
            var icon = iconEl ? iconEl.getAttribute('data-lucide') : 'circle';
            out.push({
                pathKey: pathKey,
                href: u.pathname + u.search + u.hash,
                title: title,
                icon: icon || 'circle',
            });
        });
        out.sort(function (a, b) {
            return a.title.localeCompare(b.title, undefined, { sensitivity: 'base' });
        });
        return out;
    }

    function findAnchor(item) {
        var links = document.querySelectorAll('aside a[href], #mobileSidebar a[href]');
        var i;
        for (i = 0; i < links.length; i++) {
            var a = links[i];
            if (a.getAttribute('target') === '_blank') continue;
            try {
                var u = new URL(a.href, window.location.origin);
                if (u.pathname + u.search !== item.pathKey) continue;
            } catch (e) {
                continue;
            }
            if (titleFromAnchor(a) === item.title) return a;
        }
        for (i = 0; i < links.length; i++) {
            var a2 = links[i];
            if (a2.getAttribute('target') === '_blank') continue;
            try {
                var u2 = new URL(a2.href, window.location.origin);
                if (u2.pathname + u.search === item.pathKey) return a2;
            } catch (e2) {}
        }
        return null;
    }

    function loadRecent() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return [];
            var arr = JSON.parse(raw);
            return Array.isArray(arr) ? arr : [];
        } catch (e) {
            return [];
        }
    }

    function saveRecent(items) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_RECENT)));
        } catch (e) {}
    }

    function pushRecent(item) {
        var list = loadRecent().filter(function (x) {
            return !(x.pathKey === item.pathKey && x.title === item.title);
        });
        list.unshift({ pathKey: item.pathKey, title: item.title, icon: item.icon });
        saveRecent(list);
    }

    function itemKey(it) {
        return it.pathKey + '\t' + it.title;
    }

    function matchesQuery(item, q) {
        if (!q) return true;
        var n = q.toLowerCase().trim();
        if (!n) return true;
        if (item.title.toLowerCase().indexOf(n) >= 0) return true;
        if (item.pathKey.toLowerCase().indexOf(n) >= 0) return true;
        return false;
    }

    /** @type {{ item: object }[]} */
    var flatItems = [];
    var allItems = [];
    var recentSectionCount = 0;
    var selectedIndex = 0;
    var paletteOpen = false;

    function buildFlatList() {
        var q = input.value.trim();
        allItems = collectItems();
        flatItems = [];
        recentSectionCount = 0;
        if (q) {
            allItems.forEach(function (it) {
                if (matchesQuery(it, q)) flatItems.push({ item: it });
            });
            return;
        }
        var recentRaw = loadRecent();
        var recentResolved = [];
        var used = new Set();
        recentRaw.slice(0, MAX_RECENT).forEach(function (r) {
            var found = allItems.find(function (x) {
                return x.pathKey === r.pathKey && x.title === r.title;
            });
            if (found && !used.has(itemKey(found))) {
                used.add(itemKey(found));
                recentResolved.push(found);
            }
        });
        recentResolved.forEach(function (it) {
            flatItems.push({ item: it });
        });
        recentSectionCount = recentResolved.length;
        allItems.forEach(function (it) {
            if (!used.has(itemKey(it))) flatItems.push({ item: it });
        });
    }

    function closePalette() {
        paletteOpen = false;
        root.classList.add('hidden');
        root.setAttribute('aria-hidden', 'true');
        btn.setAttribute('aria-expanded', 'false');
        input.value = '';
        document.body.classList.remove('overflow-hidden');
    }

    function openPalette() {
        paletteOpen = true;
        root.classList.remove('hidden');
        root.setAttribute('aria-hidden', 'false');
        btn.setAttribute('aria-expanded', 'true');
        document.body.classList.add('overflow-hidden');
        input.value = '';
        selectedIndex = 0;
        render();
        setTimeout(function () {
            input.focus();
            if (window.lucide) lucide.createIcons({ nodes: [root] });
        }, 10);
    }

    function togglePalette() {
        if (paletteOpen) closePalette();
        else openPalette();
    }

    function escapeHtml(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function render() {
        buildFlatList();
        if (selectedIndex >= flatItems.length) selectedIndex = Math.max(0, flatItems.length - 1);
        listEl.innerHTML = '';
        var q = input.value.trim();

        if (!flatItems.length) {
            var empty = document.createElement('div');
            empty.className = 'px-4 py-12 text-center text-sm text-gray-500 dark:text-gray-400';
            empty.textContent = i18n.empty || 'No results';
            listEl.appendChild(empty);
            return;
        }

        function appendRow(j) {
            var row = flatItems[j];
            var it = row.item;
            var idx = j;
            var btnRow = document.createElement('button');
            btnRow.type = 'button';
            btnRow.className =
                'admin-menu-palette-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ' +
                (idx === selectedIndex
                    ? 'bg-primary-500/15 text-primary-700 dark:text-primary-300 ring-2 ring-primary-500/40'
                    : 'text-gray-800 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-dark-700');
            btnRow.innerHTML =
                '<span class="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-dark-700 text-gray-600 dark:text-gray-300">' +
                '<i data-lucide="' +
                String(it.icon || 'circle').replace(/"/g, '') +
                '" class="w-4 h-4"></i></span>' +
                '<span class="min-w-0 flex-1"><span class="block text-sm font-medium truncate">' +
                escapeHtml(it.title) +
                '</span><span class="block text-[11px] text-gray-400 dark:text-gray-500 truncate font-mono">' +
                escapeHtml(it.pathKey) +
                '</span></span>';
            (function (iidx) {
                btnRow.addEventListener('click', function (ev) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    selectedIndex = iidx;
                    activateSelected();
                });
                btnRow.addEventListener('mouseenter', function () {
                    selectedIndex = iidx;
                    highlightSelectionOnly();
                });
            })(idx);
            listEl.appendChild(btnRow);
        }

        if (q) {
            for (var j = 0; j < flatItems.length; j++) appendRow(j);
        } else {
            if (recentSectionCount > 0) {
                var hR = document.createElement('div');
                hR.className =
                    'px-3 pt-2 pb-1 text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500';
                hR.textContent = i18n.recent || 'Recent';
                listEl.appendChild(hR);
                for (var r = 0; r < recentSectionCount; r++) appendRow(r);
            }
            if (recentSectionCount < flatItems.length) {
                var hA = document.createElement('div');
                hA.className =
                    'px-3 ' + (recentSectionCount > 0 ? 'pt-3 ' : 'pt-2 ') + 'pb-1 text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500';
                hA.textContent = i18n.allLabel || 'All pages';
                listEl.appendChild(hA);
                for (var k = recentSectionCount; k < flatItems.length; k++) appendRow(k);
            }
        }

        if (window.lucide) lucide.createIcons({ nodes: [listEl] });
        highlightSelectionOnly();
        scrollSelectedIntoView();
    }

    function highlightSelectionOnly() {
        var rows = listEl.querySelectorAll('button.admin-menu-palette-item');
        rows.forEach(function (row, i) {
            var on = i === selectedIndex;
            row.className =
                'admin-menu-palette-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ' +
                (on
                    ? 'bg-primary-500/15 text-primary-700 dark:text-primary-300 ring-2 ring-primary-500/40'
                    : 'text-gray-800 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-dark-700');
        });
    }

    function scrollSelectedIntoView() {
        var rows = listEl.querySelectorAll('button.admin-menu-palette-item');
        var el = rows[selectedIndex];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    }

    function activateSelected() {
        if (!flatItems.length || selectedIndex < 0 || selectedIndex >= flatItems.length) return;
        var item = flatItems[selectedIndex].item;
        pushRecent(item);
        closePalette();
        navigateToMenuItem(item);
    }

    function navigateToMenuItem(item) {
        var base = adminBase();
        var u;
        try {
            u = new URL(item.href, window.location.origin);
        } catch (e) {
            u = new URL(item.pathKey, window.location.origin);
        }
        var pathQueryHash = u.pathname + u.search + u.hash;
        var wsShell = normPathname(base + '/workspace');

        if (window.__adminWorkspace === true && typeof window.__adminWorkspaceOpenOrActivateTab === 'function') {
            if (normPathname(u.pathname) === wsShell) {
                window.__adminWorkspaceOpenOrActivateTab(base + '/dashboard', item.title, true);
                return;
            }
            window.__adminWorkspaceOpenOrActivateTab(pathQueryHash, item.title, true);
            return;
        }

        var clean = stripEmbedFromPath(pathQueryHash);
        var a = findAnchor(item);
        if (a) {
            try {
                a.click();
            } catch (e2) {
                window.location.href = clean;
            }
            return;
        }
        window.location.href = clean;
    }

    function isPaletteShortcut(e) {
        if (!e) return false;
        if (!e.ctrlKey || e.altKey) return false;
        return e.key === 'q' || e.key === 'Q';
    }

    function isEditableTarget(target) {
        var tag = (target && target.tagName) || '';
        return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (target && target.isContentEditable);
    }

    function togglePaletteFromShortcut(inEditableField, eventRef) {
        if (!paletteOpen && inEditableField) return false;
        if (eventRef && typeof eventRef.preventDefault === 'function') eventRef.preventDefault();
        if (eventRef && typeof eventRef.stopPropagation === 'function') eventRef.stopPropagation();
        togglePalette();
        return true;
    }

    function onKeydownGlobal(e) {
        if (isPaletteShortcut(e)) {
            togglePaletteFromShortcut(isEditableTarget(e.target), e);
            return;
        }
        if (!paletteOpen) return;
        if (e.key === 'Escape') {
            e.preventDefault();
            closePalette();
            return;
        }
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (flatItems.length < 1) return;
            selectedIndex = (selectedIndex + 1) % flatItems.length;
            highlightSelectionOnly();
            scrollSelectedIntoView();
            return;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (flatItems.length < 1) return;
            selectedIndex = (selectedIndex - 1 + flatItems.length) % flatItems.length;
            highlightSelectionOnly();
            scrollSelectedIntoView();
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            activateSelected();
        }
    }

    btn.addEventListener('click', function (e) {
        e.stopPropagation();
        togglePalette();
    });
    backdrop.addEventListener('click', closePalette);
    if (panel) {
        panel.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    }
    input.addEventListener('input', function () {
        selectedIndex = 0;
        render();
    });

    window.__adminMenuPaletteToggleFromShortcut = togglePaletteFromShortcut;

    document.addEventListener('keydown', onKeydownGlobal, true);
})();
