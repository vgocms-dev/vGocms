(function () {
    'use strict';

    var STORAGE_KEY = 'admin_workspace_tabs_v2';
    var MAX_TABS = 25;

    function readI18n() {
        var el = document.getElementById('admin-workspace-i18n');
        if (!el || !el.textContent) {
            return {
                closeTab: 'Close tab',
                closeOthers: 'Close other tabs',
                closeToRight: 'Close tabs to the right',
                closeAll: 'Close all tabs',
                reload: 'Reload',
                defaultTitle: 'Page',
            };
        }
        try {
            return JSON.parse(el.textContent);
        } catch (e) {
            return {};
        }
    }

    var i18n = readI18n();

    var base = window.__adminBase || '/admin';
    if (base.charAt(0) !== '/') base = '/' + base;

    var tabbar = document.getElementById('admin-workspace-tabbar');
    var stack = document.getElementById('admin-iframe-stack');
    var ctxMenu = document.getElementById('admin-workspace-ctx-menu');
    if (!tabbar || !stack) return;

    var tabs = [];
    var activeId = null;
    var ctxTargetId = null;
    var dragId = null;

    function uid() {
        return 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    function withEmbed(urlStr) {
        var u;
        try {
            u = new URL(urlStr, window.location.origin);
        } catch (e) {
            return urlStr;
        }
        u.searchParams.set('embed', '1');
        return u.pathname + u.search + (u.hash || '');
    }

    function stripEmbedForMatch(urlStr) {
        try {
            var u = new URL(urlStr, window.location.origin);
            u.searchParams.delete('embed');
            var q = u.searchParams.toString();
            return u.pathname + (q ? '?' + q : '');
        } catch (e) {
            return urlStr;
        }
    }

    function samePage(a, b) {
        return stripEmbedForMatch(a) === stripEmbedForMatch(b);
    }

    function defaultDashboardURL() {
        return withEmbed(base + '/dashboard');
    }

    function normPathname(p) {
        if (!p) return '';
        p = String(p).split('?')[0];
        if (p.length > 1 && p.lastIndexOf('/') === p.length - 1) {
            p = p.slice(0, -1);
        }
        return p;
    }

    function workspaceShellPath() {
        return normPathname(base + '/workspace');
    }

    function isOnWorkspaceShellPage() {
        return normPathname(window.location.pathname) === workspaceShellPath();
    }

    function isLinkToWorkspaceShell(hrefAttr) {
        try {
            var u = new URL(hrefAttr, window.location.origin);
            return normPathname(u.pathname) === workspaceShellPath();
        } catch (e) {
            return false;
        }
    }

    function isLogoutLink(hrefAttr) {
        try {
            var u = new URL(hrefAttr, window.location.origin);
            return normPathname(u.pathname) === normPathname(base + '/logout');
        } catch (e) {
            return false;
        }
    }

    /** Giữ shell /workspace, chỉ đổi hash — tránh ép active tab / highlight menu sai khi đổi tab. */
    function tabHashFromId(id) {
        return id ? '#t=' + encodeURIComponent(id) : '';
    }

    function parseTabIdFromLocation() {
        try {
            var h = window.location.hash || '';
            var m = /^#t=([^&]+)/.exec(h);
            if (!m) return null;
            return decodeURIComponent(m[1]);
        } catch (e) {
            return null;
        }
    }

    function replaceWorkspaceHistoryToActiveTab() {
        if (!isOnWorkspaceShellPage()) return;
        var want = window.location.pathname + window.location.search + tabHashFromId(activeId);
        var cur = window.location.pathname + window.location.search + (window.location.hash || '');
        if (want !== cur) {
            history.replaceState(null, '', want);
        }
    }

    function persist() {
        try {
            sessionStorage.setItem(
                STORAGE_KEY,
                JSON.stringify({
                    tabs: tabs.map(function (t) {
                        return {
                            id: t.id,
                            url: t.url,
                            title: t.title,
                            titleFromMenu: !!t.titleFromMenu,
                        };
                    }),
                    activeId: activeId,
                })
            );
        } catch (e) {}
    }

    function loadState() {
        try {
            var raw = sessionStorage.getItem(STORAGE_KEY);
            if (!raw) return null;
            return JSON.parse(raw);
        } catch (e) {
            return null;
        }
    }

    function getIframe(id) {
        return stack.querySelector('iframe[data-tab-id="' + id + '"]');
    }

    function setVisibleIframe(id) {
        stack.querySelectorAll('iframe.admin-workspace-iframe').forEach(function (f) {
            var on = f.getAttribute('data-tab-id') === id;
            f.style.display = on ? 'block' : 'none';
            f.style.zIndex = on ? '2' : '1';
        });
    }

    function renderTabBar() {
        tabbar.innerHTML = '';
        tabs.forEach(function (t, index) {
            var btn = document.createElement('div');
            btn.className =
                'admin-workspace-tab group flex items-center gap-1 max-w-[200px] min-w-[100px] flex-shrink-0 px-2.5 py-1.5 rounded-t-lg border border-b-0 cursor-pointer select-none text-sm ' +
                (t.id === activeId
                    ? 'bg-gray-50 dark:bg-dark-900 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white z-[1]'
                    : 'bg-gray-100 dark:bg-dark-800 border-transparent text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-dark-700');
            btn.setAttribute('role', 'tab');
            btn.setAttribute('aria-selected', t.id === activeId ? 'true' : 'false');
            btn.setAttribute('data-tab-id', t.id);
            btn.setAttribute('draggable', 'true');
            btn.dataset.index = String(index);

            var label = document.createElement('span');
            label.className = 'truncate flex-1 min-w-0';
            label.textContent = t.title || i18n.defaultTitle || 'Page';
            btn.appendChild(label);

            var close = document.createElement('button');
            close.type = 'button';
            close.className =
                'flex-shrink-0 p-0.5 rounded hover:bg-gray-300/60 dark:hover:bg-dark-600 opacity-70 hover:opacity-100';
            close.setAttribute('aria-label', i18n.closeTab || 'Close');
            close.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>';
            close.addEventListener('click', function (e) {
                e.stopPropagation();
                e.preventDefault();
                closeTab(t.id);
            });
            btn.appendChild(close);

            btn.addEventListener('click', function (e) {
                if (e.target.closest('button')) return;
                activateTab(t.id);
            });

            btn.addEventListener('auxclick', function (e) {
                if (e.button === 1) {
                    e.preventDefault();
                    closeTab(t.id);
                }
            });

            btn.addEventListener('contextmenu', function (e) {
                e.preventDefault();
                openCtxMenu(e.clientX, e.clientY, t.id);
            });

            btn.addEventListener('dragstart', function (e) {
                dragId = t.id;
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', t.id);
                btn.classList.add('opacity-50');
            });
            btn.addEventListener('dragend', function () {
                dragId = null;
                btn.classList.remove('opacity-50');
            });
            btn.addEventListener('dragover', function (e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
            });
            btn.addEventListener('drop', function (e) {
                e.preventDefault();
                var fromId = e.dataTransfer.getData('text/plain') || dragId;
                var toId = t.id;
                if (!fromId || fromId === toId) return;
                var iFrom = tabs.findIndex(function (x) {
                    return x.id === fromId;
                });
                var iTo = tabs.findIndex(function (x) {
                    return x.id === toId;
                });
                if (iFrom < 0 || iTo < 0) return;
                var moved = tabs.splice(iFrom, 1)[0];
                tabs.splice(iTo, 0, moved);
                renderTabBar();
                persist();
            });

            tabbar.appendChild(btn);
        });
        if (activeId) {
            var activeEl = tabbar.querySelector('[data-tab-id="' + activeId + '"]');
            if (activeEl) activeEl.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
        }
    }

    function applyIframeTitleIfAllowed(tabId, docTitle) {
        var t = tabs.find(function (x) {
            return x.id === tabId;
        });
        if (!t || t.titleFromMenu || !docTitle) return;
        if (menuTitleForAdminPath(stripEmbedForMatch(t.url))) return;
        var cleaned = docTitle.replace(/\s*[—–-]\s*Admin.*$/i, '').trim();
        if (cleaned) {
            t.title = cleaned;
            persist();
            renderTabBar();
        }
    }

    function openOrActivateTab(url, titleHint, titleFromMenu) {
        var fromMenu = !!titleFromMenu;
        var full = url.indexOf('http') === 0 ? url : window.location.origin + (url.charAt(0) === '/' ? url : '/' + url);
        var pathWithQuery = withEmbed(full);
        var pathForMenu = stripEmbedForMatch(pathWithQuery);
        var menuTitle = menuTitleForAdminPath(pathForMenu);
        if (menuTitle) {
            titleHint = menuTitle;
            fromMenu = true;
        }

        var existing = tabs.find(function (t) {
            return samePage(t.url, pathWithQuery);
        });
        if (existing) {
            if (titleHint) {
                if (fromMenu) {
                    existing.title = titleHint;
                    existing.titleFromMenu = true;
                } else if (!existing.titleFromMenu) {
                    existing.title = titleHint;
                }
            }
            activateTab(existing.id);
            persist();
            renderTabBar();
            return existing.id;
        }

        if (tabs.length >= MAX_TABS) {
            var removed = tabs.shift();
            if (removed) {
                var oldFrame = getIframe(removed.id);
                if (oldFrame) oldFrame.remove();
            }
        }

        var id = uid();
        var title = titleHint || i18n.defaultTitle || 'Page';
        tabs.push({ id: id, url: pathWithQuery, title: title, titleFromMenu: fromMenu });

        var iframe = document.createElement('iframe');
        iframe.className =
            'admin-workspace-iframe absolute inset-0 w-full h-full border-0 bg-gray-50 dark:bg-dark-900';
        iframe.setAttribute('data-tab-id', id);
        iframe.setAttribute('title', title);
        iframe.style.display = 'none';
        iframe.referrerPolicy = 'same-origin';
        iframe.addEventListener('load', function () {
            try {
                var doc = iframe.contentDocument;
                if (doc && doc.title) applyIframeTitleIfAllowed(id, doc.title);
            } catch (err) {}
            if (id === activeId) syncSidebarActive();
        });
        iframe.src = pathWithQuery;
        stack.appendChild(iframe);

        activateTab(id);
        persist();
        renderTabBar();
        return id;
    }

    function activateTab(id) {
        if (!tabs.some(function (t) {
            return t.id === id;
        })) return;
        activeId = id;
        setVisibleIframe(id);
        persist();
        renderTabBar();
        syncSidebarActive();
        replaceWorkspaceHistoryToActiveTab();
    }

    function workspaceHomePath(path) {
        var q = path.indexOf('?');
        var p = q >= 0 ? path.slice(0, q) : path;
        return p === base + '/dashboard' || p === base + '/workspace';
    }

    function anchorMenuLabel(a) {
        if (!a) return '';
        var attr = a.getAttribute('data-ws-tab-title');
        if (attr != null && String(attr).trim() !== '') return String(attr).trim();
        var span = a.querySelector('span.font-medium, span');
        if (span && span.textContent) return span.textContent.trim();
        return (a.textContent || '').replace(/\s+/g, ' ').trim();
    }

    function pickBestSidebarAnchorForPath(activePath) {
        if (!activePath) return null;
        if (workspaceHomePath(activePath)) {
            return document.querySelector('aside a[data-ws-home="1"], #mobileSidebar a[data-ws-home="1"]');
        }
        var best = null;
        var bestLen = -1;
        document.querySelectorAll('aside a[href], #mobileSidebar a[href]').forEach(function (a) {
            if (a.getAttribute('target') === '_blank') return;
            if (a.getAttribute('data-ws-home') === '1') return;
            try {
                var u = new URL(a.href, window.location.origin);
                if (u.origin !== window.location.origin) return;
                if (isLinkToWorkspaceShell(u.pathname + u.search)) return;
                var linkPath = stripEmbedForMatch(u.pathname + u.search);
                if (linkPath.length <= base.length) return;
                if (activePath === linkPath && linkPath.length > bestLen) {
                    best = a;
                    bestLen = linkPath.length;
                } else if (activePath.indexOf(linkPath + '/') === 0 && linkPath.length > bestLen) {
                    best = a;
                    bestLen = linkPath.length;
                }
            } catch (e) {}
        });
        return best;
    }

    function menuTitleForAdminPath(activePath) {
        var lab = anchorMenuLabel(pickBestSidebarAnchorForPath(activePath));
        if (lab) return lab;
        if (workspaceHomePath(activePath) && typeof window.__adminDefaultTabTitle === 'string' && window.__adminDefaultTabTitle.trim()) {
            return window.__adminDefaultTabTitle.trim();
        }
        return '';
    }

    function syncSidebarActive() {
        document.querySelectorAll(
            'aside a.admin-ws-link-active, aside a.admin-ws-link-active-sub, #mobileSidebar a.admin-ws-link-active, #mobileSidebar a.admin-ws-link-active-sub'
        ).forEach(function (a) {
            a.classList.remove('admin-ws-link-active', 'admin-ws-link-active-sub');
        });
        var t = tabs.find(function (x) {
            return x.id === activeId;
        });
        if (!t) return;
        var activePath = stripEmbedForMatch(t.url);
        if (workspaceHomePath(activePath)) {
            document.querySelectorAll('aside a[data-ws-home="1"], #mobileSidebar a[data-ws-home="1"]').forEach(function (home) {
                home.classList.add('admin-ws-link-active');
            });
            return;
        }
        var best = pickBestSidebarAnchorForPath(activePath);
        if (!best) return;
        if (best.classList.contains('pl-9')) {
            best.classList.add('admin-ws-link-active-sub');
        } else {
            best.classList.add('admin-ws-link-active');
        }
    }

    function closeTab(id) {
        var idx = tabs.findIndex(function (t) {
            return t.id === id;
        });
        if (idx < 0) return;
        var wasActive = activeId === id;
        tabs.splice(idx, 1);
        var iframe = getIframe(id);
        if (iframe) iframe.remove();
        hideCtxMenu();
        if (!tabs.length) {
            openOrActivateTab(defaultDashboardURL(), defaultMenuDashboardTitle(), true);
            return;
        }
        if (wasActive) {
            var next = tabs[Math.min(idx, tabs.length - 1)];
            activateTab(next.id);
        } else {
            persist();
            renderTabBar();
        }
        persist();
    }

    function closeOthers(keepId) {
        tabs = tabs.filter(function (t) {
            return t.id === keepId;
        });
        stack.querySelectorAll('iframe.admin-workspace-iframe').forEach(function (f) {
            if (f.getAttribute('data-tab-id') !== keepId) f.remove();
        });
        activeId = keepId;
        setVisibleIframe(keepId);
        hideCtxMenu();
        persist();
        renderTabBar();
        syncSidebarActive();
        replaceWorkspaceHistoryToActiveTab();
    }

    function closeToRight(ofId) {
        var idx = tabs.findIndex(function (t) {
            return t.id === ofId;
        });
        if (idx < 0) return;
        var removeIds = tabs.slice(idx + 1).map(function (t) {
            return t.id;
        });
        removeIds.forEach(function (rid) {
            var i = tabs.findIndex(function (t) {
                return t.id === rid;
            });
            if (i >= 0) tabs.splice(i, 1);
            var iframe = getIframe(rid);
            if (iframe) iframe.remove();
        });
        if (!tabs.some(function (t) {
            return t.id === activeId;
        })) {
            activeId = tabs.length ? tabs[tabs.length - 1].id : null;
        }
        if (activeId) setVisibleIframe(activeId);
        hideCtxMenu();
        persist();
        renderTabBar();
        syncSidebarActive();
        replaceWorkspaceHistoryToActiveTab();
    }

    function closeAll() {
        tabs = [];
        activeId = null;
        stack.innerHTML = '';
        hideCtxMenu();
        persist();
        openOrActivateTab(defaultDashboardURL(), defaultMenuDashboardTitle(), true);
    }

    function reloadTab(id) {
        var iframe = getIframe(id);
        if (iframe) iframe.src = iframe.src;
        hideCtxMenu();
    }

    function hideCtxMenu() {
        if (ctxMenu) {
            ctxMenu.classList.add('hidden');
            ctxMenu.innerHTML = '';
        }
        ctxTargetId = null;
    }

    function openCtxMenu(x, y, tabId) {
        ctxTargetId = tabId;
        if (!ctxMenu) return;
        var items = [
            { key: 'reload', label: i18n.reload || 'Reload', fn: function () {
                reloadTab(ctxTargetId);
            } },
            { key: 'close', label: i18n.closeTab || 'Close tab', fn: function () {
                closeTab(ctxTargetId);
            } },
            { key: 'others', label: i18n.closeOthers || 'Close others', fn: function () {
                closeOthers(ctxTargetId);
            } },
            { key: 'right', label: i18n.closeToRight || 'Close to the right', fn: function () {
                closeToRight(ctxTargetId);
            } },
            { key: 'all', label: i18n.closeAll || 'Close all', fn: closeAll },
        ];
        ctxMenu.innerHTML = '';
        items.forEach(function (item) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className =
                'w-full text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-dark-700';
            b.textContent = item.label;
            b.addEventListener('click', function () {
                item.fn();
            });
            ctxMenu.appendChild(b);
        });
        ctxMenu.classList.remove('hidden');
        ctxMenu.style.left = Math.min(x, window.innerWidth - 210) + 'px';
        ctxMenu.style.top = Math.min(y, window.innerHeight - 200) + 'px';
    }

    function hideCtxMenuIfOutside(e) {
        if (!ctxMenu || ctxMenu.classList.contains('hidden')) return;
        if (e && ctxMenu.contains(e.target)) return;
        hideCtxMenu();
    }

    document.addEventListener('mousedown', hideCtxMenuIfOutside, true);
    document.addEventListener('click', hideCtxMenuIfOutside, true);
    window.addEventListener('blur', function () {
        if (!ctxMenu || ctxMenu.classList.contains('hidden')) return;
        hideCtxMenu();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') hideCtxMenu();
    });

    function defaultMenuDashboardTitle() {
        var s = window.__adminDefaultTabTitle;
        if (typeof s === 'string' && s.trim()) return s.trim();
        return i18n.defaultTitle || 'Page';
    }

    function linkTitle(a) {
        var attr = a.getAttribute('data-ws-tab-title');
        if (attr != null && String(attr).trim() !== '') return String(attr).trim();
        var span = a.querySelector('span.font-medium, span');
        if (span && span.textContent) return span.textContent.trim();
        return (a.textContent || '').trim() || i18n.defaultTitle;
    }

    function linkUsesMenuTitle(a) {
        var attr = a.getAttribute('data-ws-tab-title');
        return attr != null && String(attr).trim() !== '';
    }

    function titleHintFromHeaderLink(a) {
        if (linkUsesMenuTitle(a)) return linkTitle(a);
        var t = (a.textContent || '').replace(/\s+/g, ' ').trim();
        if (t) return t;
        try {
            var u = new URL(a.href, window.location.origin);
            var seg = u.pathname.split('/').filter(Boolean);
            if (seg.length) return seg[seg.length - 1];
        } catch (e2) {}
        return i18n.defaultTitle || 'Page';
    }

    function isInternalAdminLink(href) {
        if (!href || href.indexOf('#') === 0 || href.indexOf('javascript:') === 0) return false;
        try {
            var u = new URL(href, window.location.origin);
            if (u.origin !== window.location.origin) return false;
            var p = u.pathname;
            return p === base || p.indexOf(base + '/') === 0;
        } catch (e) {
            return false;
        }
    }

    document.addEventListener(
        'click',
        function (e) {
            var a =
                e.target.closest &&
                e.target.closest('aside a[href], #mobileSidebar a[href], header a[href], #headerSitesApp a[href]');
            if (!a) return;
            if (a.getAttribute('target') === '_blank') return;
            if (a.getAttribute('download') != null) return;
            var href = a.getAttribute('href');
            if (!isInternalAdminLink(href)) return;
            if (isLogoutLink(href)) return;
            if (!isOnWorkspaceShellPage()) return;
            if (isLinkToWorkspaceShell(href)) {
                e.preventDefault();
                e.stopPropagation();
                var title = linkTitle(a);
                var useMenuTitle = linkUsesMenuTitle(a) || a.getAttribute('data-ws-home') === '1';
                openOrActivateTab(defaultDashboardURL(), title, useMenuTitle);
                if (typeof toggleMobileSidebar === 'function' && document.getElementById('mobileSidebar') && document.getElementById('mobileSidebar').contains(a)) {
                    toggleMobileSidebar();
                }
                return;
            }
            e.preventDefault();
            e.stopPropagation();
            var fromHeader = !!(a.closest && (a.closest('header') || a.closest('#headerSitesApp')));
            var title = fromHeader ? titleHintFromHeaderLink(a) : linkTitle(a);
            var url = new URL(a.href, window.location.origin);
            openOrActivateTab(url.pathname + url.search + (url.hash || ''), title, linkUsesMenuTitle(a));
            if (typeof toggleMobileSidebar === 'function' && document.getElementById('mobileSidebar') && document.getElementById('mobileSidebar').contains(a)) {
                toggleMobileSidebar();
            }
        },
        true
    );

    window.__adminWorkspaceOpenOrActivateTab = function (pathQueryHash, titleHint, titleFromMenu) {
        if (!isOnWorkspaceShellPage()) return false;
        openOrActivateTab(pathQueryHash, titleHint || '', !!titleFromMenu);
        return true;
    };

    window.__adminWorkspaceEmbedCtxReload = function () {
        if (!isOnWorkspaceShellPage() || !activeId) return false;
        reloadTab(activeId);
        return true;
    };
    window.__adminWorkspaceEmbedCtxCloseTab = function () {
        if (!isOnWorkspaceShellPage() || !activeId) return false;
        closeTab(activeId);
        return true;
    };
    window.__adminWorkspaceEmbedCtxCloseOthers = function () {
        if (!isOnWorkspaceShellPage() || !activeId) return false;
        closeOthers(activeId);
        return true;
    };
    window.__adminWorkspaceEmbedCtxCloseToRight = function () {
        if (!isOnWorkspaceShellPage() || !activeId) return false;
        closeToRight(activeId);
        return true;
    };
    window.__adminWorkspaceEmbedCtxCloseAll = function () {
        if (!isOnWorkspaceShellPage()) return false;
        closeAll();
        return true;
    };

    function hydrate() {
        var saved = loadState();
        if (saved && saved.tabs && saved.tabs.length) {
            tabs = [];
            stack.innerHTML = '';
            saved.tabs.forEach(function (s) {
                if (!s.url || !s.id) return;
                var url = s.url.indexOf('embed=') >= 0 ? s.url : withEmbed(s.url);
                tabs.push({
                    id: s.id,
                    url: url,
                    title: s.title || i18n.defaultTitle,
                    titleFromMenu: !!s.titleFromMenu,
                });
                var iframe = document.createElement('iframe');
                iframe.className =
                    'admin-workspace-iframe absolute inset-0 w-full h-full border-0 bg-gray-50 dark:bg-dark-900';
                iframe.setAttribute('data-tab-id', s.id);
                iframe.setAttribute('title', s.title || '');
                iframe.style.display = 'none';
                iframe.referrerPolicy = 'same-origin';
                iframe.addEventListener('load', function () {
                    try {
                        var doc = iframe.contentDocument;
                        if (doc && doc.title) applyIframeTitleIfAllowed(s.id, doc.title);
                    } catch (err) {}
                    if (s.id === activeId) syncSidebarActive();
                });
                iframe.src = url;
                stack.appendChild(iframe);
            });
            activeId = saved.activeId && tabs.some(function (t) {
                return t.id === saved.activeId;
            })
                ? saved.activeId
                : tabs[0].id;
            var hashId = parseTabIdFromLocation();
            if (hashId && tabs.some(function (t) {
                return t.id === hashId;
            })) {
                activeId = hashId;
            }
            setVisibleIframe(activeId);
            renderTabBar();
            syncSidebarActive();
            replaceWorkspaceHistoryToActiveTab();
            return;
        }
        openOrActivateTab(defaultDashboardURL(), defaultMenuDashboardTitle(), true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', hydrate);
    } else {
        hydrate();
    }
})();
